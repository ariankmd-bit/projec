import pygame
import math
import random

pygame.init()

WIDTH, HEIGHT = 1300, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Solar System - Nafas Premium Edition ✨")

clock = pygame.time.Clock()

# ------------------------------
# SETTINGS
# ------------------------------
cx, cy = WIDTH // 2, HEIGHT // 2
zoom = 1.0
font = pygame.font.SysFont("arial", 22, bold=True)

# Load galaxy background
galaxy = pygame.image.load("images/galaxy.jpg")
galaxy = pygame.transform.scale(galaxy, (WIDTH, HEIGHT))

# ------------------------------
# STARS (چشمک‌زن)
# ------------------------------
stars = []
for _ in range(150):
    x = random.randint(0, WIDTH)
    y = random.randint(0, HEIGHT)
    radius = random.randint(1, 3)
    stars.append({"x": x, "y": y, "radius": radius, "blink": random.randint(0, 50)})

# ------------------------------
# PLANETS DATA (سرعت‌ها بهینه شده)
# ------------------------------
planets = [
    {"name": "Mercury", "file": "Mercury.png", "orbit": 60, "size": 30, "speed": 0.02, "angle": 0,
     "info": "Closest planet to the Sun.\nSurface: rocky\nTemperature: 430°C day"},
    {"name": "Venus", "file": "Venus.png", "orbit": 100, "size": 38, "speed": 0.015, "angle": 0,
     "info": "Earth's sister planet.\nAtmosphere: CO2\nTemperature: 470°C"},
    {"name": "Earth", "file": "Earth.png", "orbit": 150, "size": 42, "speed": 0.012, "angle": 0,
     "info": "Our home planet.\nOceans: 71%\nMoon: 1"},
    {"name": "Mars", "file": "Mars.png", "orbit": 190, "size": 38, "speed": 0.01, "angle": 0,
     "info": "The Red Planet.\nPossibility of life.\nMoons: 2"},
    {"name": "Jupiter", "file": "Jupiter.png", "orbit": 250, "size": 70, "speed": 0.0075, "angle": 0,
     "info": "Largest planet.\nStorms: Great Red Spot\nMoons: 79"},
    {"name": "Saturn", "file": "Saturn.png", "orbit": 330, "size": 90, "speed": 0.0065, "angle": 0,
     "info": "Known for rings.\nGas giant\nMoons: 83"},
    {"name": "Neptune", "file": "Neptune.png", "orbit": 420, "size": 50, "speed": 0.0045, "angle": 0,
     "info": "Farthest planet.\nWinds: 2100 km/h\nColor: deep blue"}
]

# Load planet images
for p in planets:
    img = pygame.image.load(f"images/{p['file']}").convert_alpha()
    p["image"] = pygame.transform.scale(img, (p["size"], p["size"]))

# Sun
sun = pygame.image.load("images/Sun.png").convert_alpha()
sun = pygame.transform.scale(sun, (150, 150))

running = True
while running:
    screen.blit(galaxy, (0, 0))

    # Draw stars
    for star in stars:
        color = (255, 255, 255)
        if star["blink"] % 50 < 25:
            color = (200, 200, 255)
        pygame.draw.circle(screen, color, (star["x"], star["y"]), star["radius"])
        star["blink"] += 1

    mouse_pos = pygame.mouse.get_pos()
    hovered_planet = None

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # Zoom controls
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_EQUALS, pygame.K_PLUS):
                zoom = min(2.0, zoom + 0.1)
            if event.key == pygame.K_MINUS:
                zoom = max(0.3, zoom - 0.1)

    # Draw Sun
    sun_size = int(150 * zoom)
    sun_resized = pygame.transform.scale(sun, (sun_size, sun_size))
    screen.blit(sun_resized, (cx - sun_size // 2, cy - sun_size // 2))

    # Draw planets
    for p in planets:
        p["angle"] += p["speed"]

        x = cx + math.cos(p["angle"]) * p["orbit"]
        y = cy + math.sin(p["angle"]) * p["orbit"]

        # Resize
        img = pygame.transform.scale(
            p["image"],
            (int(p["size"] * zoom), int(p["size"] * zoom))
        )
        rect = img.get_rect(center=(x, y))
        screen.blit(img, rect)

        # Name
        text = font.render(p["name"], True, (255, 255, 255))
        screen.blit(text, (x - text.get_width() // 2, y - p["size"] * zoom - 10))

        # Orbit
        pygame.draw.circle(screen, (100, 100, 100), (cx, cy), p["orbit"], 1)
        # Hover detection
        if rect.collidepoint(mouse_pos):
            hovered_planet = (p, x, y)

    # ------------------------------
    # HOVER INFO BOX
    # ------------------------------
    if hovered_planet:
        p, px, py = hovered_planet
        lines = p["info"].split("\n")

        box_w = 240
        box_h = 20 + len(lines) * 22

        box_x = px + 40
        box_y = py - box_h // 2

        # Background box (شفاف)
        s = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        s.fill((0, 0, 0, 150))  # 150 = شفافیت
        screen.blit(s, (box_x, box_y))

        # Text
        y_offset = 5
        for line in lines:
            info_text = font.render(line, True, (255, 255, 255))
            screen.blit(info_text, (box_x + 10, box_y + y_offset))
            y_offset += 22

    pygame.display.update()
    clock.tick(60)

pygame.quit()